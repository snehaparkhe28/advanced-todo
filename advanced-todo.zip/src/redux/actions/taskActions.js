
import axios from 'axios';

export const addTask = (task) => ({
  type: 'ADD_TASK',
  payload: task,
});

export const deleteTask = (taskId) => ({
  type: 'DELETE_TASK',
  payload: taskId,
});

export const fetchTasks = () => async (dispatch) => {
  try {
    const response = await axios.get('https://jsonplaceholder.typicode.com/todos?_limit=10');
    dispatch({ type: 'SET_TASKS', payload: response.data });
  } catch (error) {
    console.error('Error fetching tasks:', error);
  }
};
